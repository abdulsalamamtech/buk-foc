<?php
/**
 * Templated sections init
 *
 * @package uni_education
 */

/**
 * Add template hooks defaults.
 */
require get_template_directory() . '/inc/template-hooks/slider.php';